package poJavaProjekt;

public class Atom {
	public double x, y, z;
	public boolean exists;
	
	public Atom(double a, double b, double c, boolean d) {
		x=a; y=b; z=c; 
		exists =d;
	}
	
	/*
	public void setExistence(boolean a)
	{
	exists = a;
	}
	
	public boolean getExistence()
	{
	return exists;
	}
	*/
}
